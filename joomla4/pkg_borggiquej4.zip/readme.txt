Borggique version 1.0.0  is a free software which is developed by
Kian William Nowrouzian. 
It is a package including both component, module and plugin.
Both component in site part and module use content plugin, so without it,
 it will not work and be sure after upload to make the plugin enabled
from Joomla backend.
The license is GNU/GPLv3.
It is written for joomla 3.x,
In comment part for special characters add backslash(\) before them.
you may download the component at:http://www.myextenstions.lord121.ir//.html
In case of any problem contact me at:
mezmer121@gmail.com
long live science.
