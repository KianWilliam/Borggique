<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerScript;

class Pkg_BorggiqueInstallerScript extends InstallerScript
{
 public function install($parent)
 {
  
   
  $db  = Factory::getDbo();
  $query = $db->getQuery(true);
  $query->update('#__extensions');
  $query->set($db->quoteName('enabled') . ' = 1');
  $query->where($db->quoteName('element') . ' = ' . $db->quote('borggique'));
  $query->where($db->quoteName('type') . ' = ' . $db->quote('plugin'));
  $db->setQuery($query);
  $db->execute(); 
  
   
  
 }
   public function uninstall($parent) 
  {
	   $db  = Factory::getDbo();
	       
       $query = "DROP IF EXISTS TABLE `#__borggique`";
	   $db->setQuery($query);
			$db->execute();
			
	
  }
}
